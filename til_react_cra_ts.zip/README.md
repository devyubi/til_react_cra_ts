# useState

- React 용 변수임 (실제론 리엑트용 변수란건 없지만, 수업 편의성으로 그렇게 부르고있음)
- set 으로 값을 변화시키면 rerendering 을 함

## 1. 기본예제

- /src/components 폴더
- /src/components/Counter.tsx 파일 생성

- 기존 배웠던 문법 실습

```tsx
import { useState } from 'react';

// 2번 이상 반복되고, 가독성이 떨어짐
// 1. type 으로 정의 해보기
type VoidFunction = () => void;
type JSXElement = () => JSX.Element;

// 2. interface 로 정의해보기
interface IVoidFunction {
  (): void;
}
interface IJSXElement {
  (): JSX.Element;
}

const Counter: IJSXElement | JSXElement = (): JSX.Element => {
  // ts 자리
  const [count, setCount] = useState<number>(0);

  const handleAdd: IVoidFunction | VoidFunction = () => {
    setCount(count + 1);
  };
  const handleMinus: IVoidFunction | VoidFunction = () => {
    setCount(count - 1);
  };
  const handleReset: IVoidFunction | VoidFunction = () => {
    setCount(0);
  };
  // tsx 자리
  return (
    <div>
      <h2>Counte : {count} </h2>
      <button onClick={handleAdd}>증가</button>
      <button onClick={handleMinus}>감소</button>
      <button onClick={handleReset}>초기화</button>
    </div>
  );
};

export default Counter;
```

## 2. 실습 예제

- /src/components/NameEditor.tsx 파일 추가
