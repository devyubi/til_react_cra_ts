import Counter from './components/Counter';
import NameEditor from './components/NameEditor';

function App() {
  return (
    <div>
      <h1>useState 예제</h1>
      <Counter />
      <NameEditor />
    </div>
  );
}

export default App;
