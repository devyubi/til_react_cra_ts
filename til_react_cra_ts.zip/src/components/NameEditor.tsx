import { ChangeEvent, useState } from 'react';

const NameEditor = () => {
  // ts 자리
  const [name, setName] = useState('');
  const handleName = (e: ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
  };

  // tsx 자리
  return (
    <div>
      <h2>NameEditor : {name} </h2>
      <div>
        <input type="text" value={name} onChange={e => handleName(e)} />
        <button>확인</button>
      </div>
    </div>
  );
};

export default NameEditor;
